﻿using UnityEngine;

internal class rb
{
    internal static Vector2 velocity;
}